package org.example;

import org.junit.Test;
import org.junit.jupiter.api.*;

@DisplayName("test sum class")
@TestMethodOrder(MethodOrderer.class)
public class TestSum {

    Sum unitUnderTest = new Sum();


    @BeforeAll
    public void beforeEachMethod(){
        //connect db
        System.out.println("beforeEachMethod");
    }

    @AfterAll
    public void afterEachMethod(){
        //disconnect db
        System.out.println("afterEachMethod");
    }

    @Test
    @Order(1)
    @DisplayName("Test Sum Method..........")
    public void testSumMethod() {
        //connect db


        double result = unitUnderTest.divideNumbers(10.0, 2.0);
        Assertions.assertEquals(5.0, result);



                //TestNG
                //Junit-4, 5



    }

    @Test
    @DisplayName("Test Sum Method number divide by zero")
    public void testDivideByZero() {

        double result = unitUnderTest.divideNumbers(10.0, 0.0);
        Assertions.assertEquals(Double.POSITIVE_INFINITY, result);
        //disconnect db
    }

    @Test
    @Order(2)
    @DisplayName("Test Sum Method zero divide by zero")
    public void testZeroDivideByZero() {
        double result = unitUnderTest.divideNumbers(0.0, 0.0);
        Assertions.assertEquals(Double.NaN, result);
    }
}
