package org.example;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class ShoppingCartTest {


    @Test
    public void testEmptyCart(){
        ShoppingCart cart = new ShoppingCart();
        int count =cart.getProduct();
        Assertions.assertEquals(0, count);
    }

    @Test
    public void testSingleProductCart(){
        ShoppingCart cart = new ShoppingCart();
        Product product= new Product("Sun's Cream", 1, 30.0);
        cart.addProduct(product);
        int count =cart.getProduct();
        Assertions.assertEquals(1, count);
    }


    @Test
    public void testMultipleProductCart(){
        ShoppingCart cart = new ShoppingCart();
        Product product1= new Product("Sun's Cream", 1, 30.0);
        Product product2= new Product("Hair oil", 1, 100.00);
        cart.addProduct(product1);
        cart.addProduct(product2);
        int count =cart.getProduct();
        Assertions.assertEquals(2, count);
        double totalCartPrice= cart.getTotalCartPrice();
        Assertions.assertEquals(130.0, totalCartPrice);
    }

    // offer
    // Buy 2 get 1 free
    // Buy X items and get y items free.

    //5 suns cream
    //30
    //30
    //30 - free
    //30
    //30
    //30- free

    @Test
    public void testBuyXItemAndGetYItemFreeOnSingleProduct(){
        ShoppingCart cart = new ShoppingCart();
        Product product1= new Product("Sun's Cream", 6, 180.00); //30 each, 30*5=150  -> 120
        IOffer buy2Get1FreeOffer = new BuyXItemGetYItemFreeOffer(2, 1);
        cart.applyOffer(buy2Get1FreeOffer); //apply offer , Buy2 get 1 free
        cart.addProduct(product1);

        int count =cart.getProduct();
        Assertions.assertEquals(1, count);
        double totalCartPrice= cart.getTotalCartPrice();
        Assertions.assertEquals(120, totalCartPrice);
    }


    @Test
    public void testBuyXItemAndGetYItemFree(){
        ShoppingCart cart = new ShoppingCart();
        Product product1= new Product("Sun's Cream", 5, 150.0); //30 each, 30*5=150  -> 120
        IOffer buy2Get1FreeOffer = new BuyXItemGetYItemFreeOffer(2, 1);
        cart.applyOffer(buy2Get1FreeOffer); //apply offer , Buy2 get 1 free
        cart.addProduct(product1);

        Product product2= new Product("Hair oil", 1, 100.00); // 100
        IOffer noOffer = new NoOffer();
        cart.applyOffer(noOffer); //no offer
        cart.addProduct(product2);

        int count =cart.getProduct();
        Assertions.assertEquals(2, count);
        double totalCartPrice= cart.getTotalCartPrice();
        Assertions.assertEquals(220, totalCartPrice);
    }

}
