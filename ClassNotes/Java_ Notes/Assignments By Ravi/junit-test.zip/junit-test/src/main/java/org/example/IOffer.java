package org.example;

public interface IOffer {
    void applyOffer(Product product);
}
