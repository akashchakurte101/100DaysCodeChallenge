package org.example;

public class Sum {


    public double divideNumbers(double a, double b){
        return a/b;
    }
}
