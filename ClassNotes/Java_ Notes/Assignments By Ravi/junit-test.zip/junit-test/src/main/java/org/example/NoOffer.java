package org.example;

public class NoOffer implements IOffer{
    @Override
    public void applyOffer(Product product) {
        //no offer
    }
}
