package org.example;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

    private List<Product> productList = new ArrayList<>();
    private IOffer offer;

    public int getProduct() {
        return productList.size();
    }

    public void addProduct(Product product) {
        if(null != offer){
            offer.applyOffer(product);
        }
        productList.add(product);
    }

    public double getTotalCartPrice() {
        double totalPrice = 0.0;
        for (Product product : productList) {
            totalPrice = totalPrice + product.getTotalProductPrice();
        }
        return totalPrice;
    }

    public void applyOffer(IOffer offer ){
        this.offer=offer;
    }
}
