package org.example;

public class BuyXItemGetYItemFreeOffer implements IOffer {

    private int xItem;
    private int yItem;

    public BuyXItemGetYItemFreeOffer(int xItem, int yItem) {
        this.xItem = xItem;
        this.yItem = yItem;
    }

    @Override
    public void applyOffer(Product product) {
        //buy 2 get 1 free
        if (product.getProductQuantity() >= xItem) {
            int freeProductQuantity = product.getProductQuantity() / (xItem + yItem);
            double unitPrice = product.getTotalProductPrice() / product.getProductQuantity();
            double discount = unitPrice * freeProductQuantity;
            product.setTotalProductPrice(product.getTotalProductPrice() - discount);
        }
    }
}
