package hackerrank;

/**
 * FURNITURE_TYPE("Furniture Name", floating-point cost)
*/


public enum Furniture {
	CHAIR("Chair", 100.0f),
	TABLE("Table", 250.0f),
	COUCH("Couch", 500.0f);
	
	//provide your implementation
}
