package hackerrank;

/**
 * FURNITURE_TYPE("Furniture Name", floating-point cost)
*/


public enum Furniture {
	CHAIR("Chair", 100.0f),
	TABLE("Table", 250.0f),
	COUCH("Couch", 500.0f);

	private String label;

	private float cost;
	Furniture(String label, Float cost){
		this.label=label;
		this.cost=cost;
	}

	public String label() {
		return label;
	}

	public Float cost() {
		return cost;
	}
}
