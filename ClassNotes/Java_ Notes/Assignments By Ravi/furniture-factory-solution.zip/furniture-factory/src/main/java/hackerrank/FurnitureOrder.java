package hackerrank;

import java.util.HashMap;
import java.util.Map;

public class FurnitureOrder implements FurnitureOrderInterface {

    HashMap<Furniture, Integer> map = new HashMap<>();

    public void addToOrder(final Furniture type, final int furnitureCount) {
        map.put(type, furnitureCount);
    }

    public HashMap<Furniture, Integer> getOrderedFurniture() {
        return this.map;
    }

    public float getTotalOrderCost() {

        float totalOrderCost = 0.0F;
        for (Map.Entry<Furniture, Integer> m : map.entrySet()) {

            Furniture furniture = m.getKey();
            Integer itemsCount = m.getValue();

            float unitItemPrice = furniture.cost();
            totalOrderCost = totalOrderCost + (unitItemPrice * itemsCount);
        }

        return totalOrderCost;
        //return (float) map.entrySet().stream().mapToDouble(entry -> entry.getKey().cost() * entry.getValue()).sum();
    }

    public int getTypeCount(Furniture type) {
        return map.containsKey(type) ? map.get(type) : 0;
    }

    public float getTypeCost(Furniture type) {
        return map.containsKey(type) ? map.get(type) * type.cost() : 0;
    }

    public int getTotalOrderQuantity() {

        int totalOrderQuantity = 0;
        for (Map.Entry<Furniture, Integer> m : map.entrySet()) {

            Furniture furniture = m.getKey();
            Integer itemsCount = m.getValue();

            totalOrderQuantity = totalOrderQuantity + itemsCount;
        }
        return totalOrderQuantity;
        //return map.entrySet().stream().mapToInt(entry -> entry.getValue()).sum();
    }

}